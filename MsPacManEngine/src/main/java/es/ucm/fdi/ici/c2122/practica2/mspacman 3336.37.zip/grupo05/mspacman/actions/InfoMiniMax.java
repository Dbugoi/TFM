package es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions;

import java.util.List;

import es.ucm.fdi.ici.c2122.practica2.grupo05.GameUtils;
import pacman.controllers.GhostController;
import pacman.game.Game;
import pacman.game.Constants.MOVE;

public class InfoMiniMax {

	private int p;
	private MOVE finalMove;
	private static int limitForChasingGhost = 50;
	
	public InfoMiniMax(int points, MOVE m) {
		this.p =points;
		this.finalMove = m;
	}
	
	public int getPoints() {
		return p;
	}
	
	public MOVE getMove() {
		return finalMove;
	}
	
	static InfoMiniMax minimax(Game game, int mspacman, List<MOVE> goodMoves, int depth, boolean maximizing, int alpha, int beta, GhostController ghosts) {
		InfoMiniMax info = new InfoMiniMax(game.getScore(), MOVE.NEUTRAL);
		int timeLimit = 40;
		if (game.gameOver() || depth ==0) {
			return info;
		} 
 
		if (maximizing) {
			int bestScore = Integer.MIN_VALUE;
			for (MOVE m : goodMoves) {
				Game newGame = game.copy();
				newGame.advanceGame(m, ghosts.getMove(game, System.currentTimeMillis() + timeLimit));
				List<Integer> listChasingGhosts = GameUtils.getNearestChasingGhosts(newGame, limitForChasingGhost);
				goodMoves = GameUtils.getGoodMoves(newGame, listChasingGhosts,mspacman);
				
				info = minimax(newGame, mspacman, goodMoves, depth - 1, false, alpha, beta, ghosts);
				
				bestScore = Math.max(bestScore, info.getPoints());
				alpha = Math.max(info.getPoints(), alpha);
				if (beta <= alpha)
						break;
				
			}
			return info;
		} 
		else {
			int bestScore = Integer.MAX_VALUE;
			for (MOVE m : goodMoves) {
				Game newGame = game.copy();
				newGame.advanceGame(m, ghosts.getMove(game, System.currentTimeMillis() + timeLimit));
				List<Integer>  listChasingGhosts = GameUtils.getNearestChasingGhosts(newGame, limitForChasingGhost);
				goodMoves = GameUtils.getGoodMoves(newGame, listChasingGhosts,mspacman);
				
				info = minimax(newGame, mspacman, goodMoves, depth - 1, true, alpha, beta, ghosts);
					

				bestScore = Math.min(bestScore, info.getPoints());
				beta = Math.min(info.getPoints(), beta);
				if (beta <= alpha)
					break;
				
			}
		return info;
		}
	}

}
