package es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Random;

import es.ucm.fdi.ici.Action;
import es.ucm.fdi.ici.c2122.practica2.grupo05.GameUtils;
import es.ucm.fdi.ici.c2122.practica2.grupo05.NearestEdibleGhostInformation;
import pacman.controllers.GhostController;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class ChaseGhostAction implements Action {

	private int limitForChasingGhost = 55;
	private int limitForEdibleGhost = 50;
	public ChaseGhostAction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public MOVE execute(Game game) {
		int mspacman = game.getPacmanCurrentNodeIndex();
		
		List<Integer> listChasingGhosts = GameUtils.getNearestChasingGhosts(game, limitForChasingGhost);
		NearestEdibleGhostInformation edibleGhostsINFO = GameUtils.getNearestEdibleGhosts(game, this.limitForEdibleGhost);
		
		List<MOVE> goodMoves = GameUtils.getGoodMoves(game, listChasingGhosts,mspacman);
		List<MOVE> movesToEatGhosts = new ArrayList<>();
		if(edibleGhostsINFO.getListNearestEdibleGhost().size()>0)
		{
			MOVE finalMove = GameUtils.getBestMovesTowardsGhost(game, edibleGhostsINFO.getListNearestEdibleGhost(), goodMoves);
			
			for(Integer index: edibleGhostsINFO.getListNearestEdibleGhost()) {
				if(goodMoves.contains(game.getNextMoveTowardsTarget(mspacman, index, DM.PATH)));
					movesToEatGhosts.add(game.getNextMoveTowardsTarget(mspacman, index, DM.PATH));
			}
		}
		
	
		GhostController gc = new GhostController() {
					EnumMap<GHOST, MOVE> moves = new EnumMap<>(GHOST.class);
					@Override
					public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
						// TODO Auto-generated method stub
						for(GHOST g : GHOST.values()) 
							if(!game.isGhostEdible(g))
								 moves.put(g, game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(g), game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(g), DM.PATH));
							else 
								moves.put(g, game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(g), game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(g), DM.PATH));
						return moves;
					}
				};
				
		//InfoMiniMax info = InfoMiniMax.minimax(game,  game.getPacmanCurrentNodeIndex(),  MOVE.NEUTRAL,  45, true,Integer.MIN_VALUE, Integer.MAX_VALUE, gc);
			
		Random rnd = new Random();
		if(goodMoves.size()==0)
			return MOVE.NEUTRAL;
		else if (movesToEatGhosts.size()>0)
			return movesToEatGhosts.get(rnd.nextInt(movesToEatGhosts.size()));
		else
			return goodMoves.get(rnd.nextInt(goodMoves.size()));
	}

	@Override
	public String getActionId() {
		return "Chase Edible Ghost Action";
	}

}