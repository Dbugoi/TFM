package es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions;

import java.util.List;
import java.util.Random;

import es.ucm.fdi.ici.Action;
import es.ucm.fdi.ici.c2122.practica2.grupo05.GameUtils;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.MOVE;

public class EatPowerPillAction implements Action {

	private int limitForChasingGhost = 50;
	public EatPowerPillAction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public MOVE execute(Game game) {
		int mspacman = game.getPacmanCurrentNodeIndex();
		
		List<Integer> listChasingGhosts = GameUtils.getNearestChasingGhosts(game, limitForChasingGhost);
		
		List<MOVE> goodMoves = GameUtils.getGoodMoves(game, listChasingGhosts,mspacman);
		
		int indexPowerPill = GameUtils.getNearestPowerPillWithoutChasingGhost(game, goodMoves);
		
		Random rnd = new Random();
		if(indexPowerPill==-1 && goodMoves.size()==0)  // resumir estas 2 con minimax
				return MOVE.NEUTRAL;
		else if(indexPowerPill == -1 && goodMoves.size()>0)
				return goodMoves.get(rnd.nextInt(goodMoves.size()));  
		else if(goodMoves.contains(game.getNextMoveTowardsTarget(mspacman, indexPowerPill, DM.PATH)))
			return game.getNextMoveTowardsTarget(mspacman, indexPowerPill, DM.PATH);
		else
			return goodMoves.get(rnd.nextInt(goodMoves.size()));
	}

	@Override
	public String getActionId() {
		return "Eat Pills Action";
	}
}