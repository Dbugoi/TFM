package es.ucm.fdi.ici.c2122.practica2.grupo05;

import java.util.List;

import es.ucm.fdi.ici.Input;
import pacman.game.Game;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class MsPacManInput extends Input {

	private boolean nearEdibleGhost; // si existe un Ghost cercano comestible
	private boolean nearEdibleGhost2; // si existe un Ghost cercano comestible
	private boolean nearChasingGhost; // si existe un Ghost cercano NO comestible
	//private boolean nearPPill; // si existe una PPill cercana
	private boolean nearDangerousCage;
	private boolean nearPill; // si existe una Pill cercana
	private boolean nearPPill; // si existe una Pill cercana
	private int limitForChasingGhost = 55;
	private int limitForEdibleGhost = 40;
	private int limitForEdibleGhost2 = 65;
	private boolean edibleGhostIsToGoingChange;
	public MsPacManInput(Game game) {
		super(game);
		NearestEdibleGhostInformation edibleGhostsINFO = GameUtils.getNearestEdibleGhosts(game, this.limitForEdibleGhost);
		List<MOVE> goodMoves = GameUtils.getGoodMoves(game, edibleGhostsINFO.getListNearestEdibleGhost(),game.getPacmanCurrentNodeIndex());
		if(GameUtils.getNearestChasingGhosts(game, limitForChasingGhost).size()>0)
			nearChasingGhost =true;
		else
			nearChasingGhost =false;
		
		if(edibleGhostsINFO.getListNearestEdibleGhost().size()>0)
			nearEdibleGhost =true;
		else
			nearEdibleGhost =false;
		
		if(GameUtils.getNearestPillWithoutChasingGhost(game, goodMoves)!=-1)
			nearPill =true;
		else
			nearPill=false;
		if(GameUtils.getNearestPowerPillWithoutChasingGhost(game, goodMoves)!=-1)
			nearPPill =true;
		else
			nearPPill=false;
	
	
		if(edibleGhostsINFO.getMinDistanceNearestGhost() + edibleGhostsINFO.getMinEdibleTimeNearestGhost()/2 < edibleGhostsINFO.getMinEdibleTimeNearestGhost() )
			edibleGhostIsToGoingChange = true;
		else 
			edibleGhostIsToGoingChange = false;
		
		nearDangerousCage=GameUtils.nearDangerousCage(game);
		
		edibleGhostsINFO = GameUtils.getNearestEdibleGhosts(game, this.limitForEdibleGhost2);
		if(edibleGhostsINFO.getListNearestEdibleGhost().size()>0)
			nearEdibleGhost2 =true;
		else
			nearEdibleGhost2=false;
	}

	@Override
	public void parseInput() {
		// does nothing.

		
		
	}
	
	public boolean existsNearEdibleGhosts() {
		return nearEdibleGhost;
	}
	public boolean existsNearEdibleGhosts2() {
		return nearEdibleGhost2;
	}
	public boolean existsNearChasingGhosts() {
		return nearChasingGhost;
	}
	public boolean existsNearPill() {
		return nearPill;
	}
	public boolean existsNearPowerPill() {
		return nearPPill;
	}

	public boolean dangerEdibleGhost() {
		return edibleGhostIsToGoingChange;
	}
	
	public boolean nearDangerousCage() {
		return nearDangerousCage;
	}
}
