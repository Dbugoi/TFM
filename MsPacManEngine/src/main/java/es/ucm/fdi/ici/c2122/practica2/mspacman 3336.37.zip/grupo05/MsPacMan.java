package es.ucm.fdi.ici.c2122.practica2.grupo05;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import es.ucm.fdi.ici.fsm.CompoundState;
import es.ucm.fdi.ici.fsm.FSM;
import es.ucm.fdi.ici.Input;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.ChaseGhostAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.EatPillsAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.EatPowerPillAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.MsPacManRandomAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.MsPacManReappearsAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.PatrolAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.actions.RunAwayCageAction;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.EatPillTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.EatPowerPillTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.GoForEdibleGhostTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.MsPacManDiesTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.PatrolTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.RunAwayFromCageTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.RunAwayFromChasingGhostTransition;
import es.ucm.fdi.ici.c2122.practica2.grupo05.mspacman.transitions.RunAwayFromEdibleChangingGhostTransition;
import es.ucm.fdi.ici.fsm.SimpleState;
import es.ucm.fdi.ici.fsm.Transition;
import es.ucm.fdi.ici.fsm.observers.GraphFSMObserver;
import pacman.controllers.PacmanController;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

/*
 * The Class NearestPillPacMan.
 */
public class MsPacMan extends PacmanController {

	FSM fsm;
	public MsPacMan() {
		setName("MsPacMan XX");
		
    	fsm = new FSM("MsPacMan");
    	
    	GraphFSMObserver observer = new GraphFSMObserver(fsm.toString());
    	fsm.addObserver(observer);
    	
    	
    	SimpleState patrolState = new SimpleState("patrolState", new PatrolAction());
    	SimpleState chaseGhostState = new SimpleState("chaseGhostState", new ChaseGhostAction());
    	SimpleState eatPowerPillState = new SimpleState("eatPowerPillState", new EatPowerPillAction());
    	SimpleState eatPillsState = new SimpleState("eatPillsState", new EatPillsAction());
    	SimpleState msPacManRandomState = new SimpleState("msPacManRandomState", new MsPacManRandomAction());
    	SimpleState msPacManReappearsAction = new SimpleState("msPacManReappearsAction", new MsPacManReappearsAction());
    	SimpleState runAwayCageAction = new SimpleState("runAwayCageAction",new RunAwayCageAction());
    	
    	//Transition patrolTransition = new PatrolTransition();
    	// Transition goForEdibleGhostTransition = new GoForEdibleGhostTransition();
    	//Transition eatPowerPillTransition = new EatPowerPillTransition();
    	Transition eatPillTransition = new EatPillTransition();
    	//Transition msPacManDiesTransition = new MsPacManDiesTransition();
    	//Transition runAwayFromCageTransition = new RunAwayFromCageTransition();
    	//Transition runAwayFromChasingGhostTransition = new RunAwayFromChasingGhostTransition();
    	Transition runAwayFromEdibleChangingGhostTransition = new RunAwayFromEdibleChangingGhostTransition();
    	
    	FSM cfsm1 = new FSM("ChaseGhosts");
    	//GraphFSMObserver c1observer = new GraphFSMObserver(cfsm1.toString());
    	//cfsm1.addObserver(c1observer);

    	cfsm1.add(chaseGhostState, new EatPowerPillTransition("ChaseGhosts"), eatPowerPillState);
    	cfsm1.add(eatPowerPillState,  new GoForEdibleGhostTransition("ChaseGhosts"), chaseGhostState);
    	cfsm1.ready(chaseGhostState);
    	CompoundState chase_Ghosts = new CompoundState("chase_Ghosts", cfsm1);
    	
    	FSM cfsm2 = new FSM("RunAwayGhosts");
    	//GraphFSMObserver c2observer = new GraphFSMObserver(cfsm2.toString());
    	//cfsm2.addObserver(c2observer);

    	cfsm2.add(eatPillsState, new EatPowerPillTransition("RunAwayGhosts"), eatPowerPillState);
    	cfsm2.add(eatPowerPillState, new RunAwayFromChasingGhostTransition("eatPowerPillState"), eatPillsState);
    	cfsm2.ready(eatPillsState);
    	CompoundState runAway_Ghosts = new CompoundState("runAway_Ghosts", cfsm2);
    	
    	FSM cfsm3 = new FSM("Patrol");
    	//GraphFSMObserver c3observer = new GraphFSMObserver(cfsm3.toString());
    	//cfsm3.addObserver(c3observer);

    	cfsm3.add(msPacManRandomState, eatPillTransition, eatPillsState);
    	cfsm3.add(eatPillsState, new PatrolTransition("eatPillsState"), msPacManRandomState);
    	cfsm3.ready(msPacManRandomState);
    	CompoundState patrol = new CompoundState("patrol", cfsm3);
    	
    	fsm.add(msPacManReappearsAction, new GoForEdibleGhostTransition("msPacManReappears"), chase_Ghosts);
    	fsm.add(msPacManReappearsAction, new RunAwayFromCageTransition("msPacManReappears"), runAwayCageAction);
    	fsm.add(msPacManReappearsAction, new RunAwayFromChasingGhostTransition("msPacManReappears"), runAway_Ghosts);
    	fsm.add(msPacManReappearsAction, new PatrolTransition("msPacManReappears"), patrol);
    	
    	//En Perseguir
    	fsm.add(chase_Ghosts, new PatrolTransition("chase_Ghosts"), patrol);
    	
    	
    	fsm.add(chase_Ghosts,  new RunAwayFromChasingGhostTransition("chase_Ghosts"), runAway_Ghosts);
    	fsm.add(chase_Ghosts,  new MsPacManDiesTransition("chase_Ghosts"), msPacManReappearsAction);
    	
    	//En Huir Ghosts
    	fsm.add(runAway_Ghosts,  new GoForEdibleGhostTransition("runAway_Ghosts"), chase_Ghosts);
    	fsm.add(runAway_Ghosts,  new RunAwayFromCageTransition("runAway_Ghosts"), runAwayCageAction);
    	fsm.add(runAway_Ghosts, new PatrolTransition("runAway_Ghosts"), patrol);
    	fsm.add(runAway_Ghosts,  new MsPacManDiesTransition("runAway_Ghosts"), msPacManReappearsAction);
    	
    	//En Huir Cage
    	fsm.add(runAwayCageAction,  new GoForEdibleGhostTransition("runAwayCage"), chase_Ghosts);
    	fsm.add(runAwayCageAction, new RunAwayFromChasingGhostTransition("runAwayCage"), runAway_Ghosts);
    	fsm.add(runAwayCageAction, new PatrolTransition("runAwayCage"), patrol);
    	fsm.add(runAwayCageAction,  new MsPacManDiesTransition("runAwayCage"), msPacManReappearsAction);
    	
    	//En Patrol Cage
       	fsm.add(patrol,   new GoForEdibleGhostTransition("patrol"), chase_Ghosts);
    	fsm.add(patrol, new RunAwayFromChasingGhostTransition("patrol"), runAway_Ghosts);
    	fsm.add(patrol,  new RunAwayFromCageTransition("patrol"), runAwayCageAction);
    	fsm.add(patrol,  new MsPacManDiesTransition("patrol"), msPacManReappearsAction);
    	
    	fsm.ready(msPacManReappearsAction);
    	
    	JFrame frame = new JFrame();
    	JPanel main = new JPanel();
    	main.setLayout(new BorderLayout());
    	main.add(observer.getAsPanel(true, null), BorderLayout.CENTER);
    	//main.add(c1observer.getAsPanel(true, null), BorderLayout.SOUTH);
    	frame.getContentPane().add(main);
    	frame.pack();
    	frame.setVisible(true);
	}
	
	
	public void preCompute(String opponent) {
    		fsm.reset();
    }
	
	
	
    /* (non-Javadoc)
     * @see pacman.controllers.Controller#getMove(pacman.game.Game, long)
     */
    @Override
    public MOVE getMove(Game game, long timeDue) {
    	int i=0;
    	if(game.isJunction(game.getPacmanCurrentNodeIndex()))
    		i=1;
       	Input in = new MsPacManInput(game); 
    	return fsm.run(in);
    }
    
    
}